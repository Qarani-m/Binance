<script setup>
import { ref } from 'vue'

const activeDropdown = ref(null)

const tradeDropdown = {
  basic: [
    { name: 'Spot', desc: 'Buy and sell on the Spot market with advanced tools', icon: '📊' },
    { name: 'Margin', desc: 'Increase your profits with leverage', icon: '📈' },
    { name: 'P2P', desc: 'Buy & sell cryptocurrencies using bank transfer and 800+ options', icon: '👥' },
    { name: 'Convert & Block Trade', desc: 'The easiest way to trade at all sizes', icon: '🔄' }
  ],
  advanced: [
    { name: 'Trading Bots', desc: 'Trade smarter with our various automated strategies - easy and reliable', icon: '🤖' },
    { name: 'Copy Trading', desc: 'Follow the most popular traders', icon: '📋' },
    { name: 'Alpha', desc: 'Quick access to Web3 via Alpha Trading', icon: '🌐', path: '/alpha' },
    { name: 'APIs', desc: 'Unlimited opportunities with one key', icon: '😊' }
  ]
}

const futuresDropdown = [
  { name: 'USD⊝-M Futures', desc: 'Contracts settled in USDT and USDC', icon: '📄', path: '/futures' },
  { name: 'COIN-M Futures', desc: 'Contracts settled in cryptocurrency', icon: '📄', path: '/coin-m' },
  { name: 'Options', desc: 'USDT Options with limited downside and affordable entry', icon: '📊', path: '/options' }
]

const earnDropdown = [
  { name: 'Overview', desc: 'One-stop portal for all Earn products', icon: '🔒', path: '/earn' },
  { name: 'Simple Earn', desc: 'Earn passive income on 300+ crypto assets with flexible and locked terms', icon: '💰', path: '/earn/simple' },
  { name: 'Advanced Earn', desc: 'Maximize your returns with our advanced yield investment products', icon: '📈', path: '/earn/advanced' },
  { name: 'Loans', desc: 'Access quick and easy loans with competitive rates', icon: '🏦', path: '/earn/loan' }
]

const squareDropdown = [
  { name: 'Square', desc: 'Stay informed with everything crypto', icon: '📶', path: '/square' },
  { name: 'Blog', desc: 'Expand your knowledge and get the latest insights', icon: '📝', path: '/blog' },
  { name: 'Research', desc: 'Institutional-grade analysis, in-depth insights, and more', icon: '🔬', path: '/research' }
]

const moreDropdown = [
  { name: 'VIP & Institutional', desc: 'Your trusted digital asset platform for VIPs and institutions', icon: '💎', path: '/vip' },
  { name: 'Launchpool', desc: 'Discover and gain access to new token launches', icon: '🚀', path: '/launchpool' },
  { name: 'Binance Wallet', desc: 'Access and Navigate Web3 Effortlessly', icon: '👛', path: '/web3wallet' },
  { name: 'Binance Academy', desc: 'Free crypto & blockchain education', icon: '🎓', path: '/academy' }
]

const props = defineProps({
  isFixed: {
    type: Boolean,
    default: true
  }
})
</script>

<template>
  <header
    :class="[isFixed ? 'fixed top-0 left-0 right-0 z-50 h-[64px]' : 'h-[64px] flex-none', 'bg-bg-base border-b border-[#2b3139] px-6 flex items-center justify-between']">
    <!-- Left Side: Logo & Nav -->
    <div class="flex items-center gap-6 h-full">
      <!-- Logo -->
      <router-link to="/" class="flex items-center gap-2 group">
        <svg class="text-primary w-[120px]" viewBox="0 0 1000 200" fill="currentColor">
          <path d="M180,50 L200,50 L200,150 L180,150 Z" opacity="0" />
          <text x="0" y="140" font-family="Arial" font-weight="bold" font-size="120" fill="#FCD535">BINANCE</text>
        </svg>
      </router-link>

      <!-- Desktop Nav -->
      <nav class="hidden xl:flex items-center h-full">
        <router-link to="/buy-crypto"
          class="flex items-center h-full px-3 text-[14px] font-medium text-text-primary hover:text-primary transition-colors cursor-pointer">
          Buy Crypto
        </router-link>
        <router-link to="/markets"
          class="flex items-center h-full px-3 text-[14px] font-medium text-text-primary hover:text-primary transition-colors cursor-pointer">
          Markets
        </router-link>

        <!-- Trade Dropdown -->
        <div class="relative h-full" @mouseenter="activeDropdown = 'trade'" @mouseleave="activeDropdown = null">
          <a href="#" class="flex items-center h-full px-3 text-[14px] font-medium transition-colors cursor-pointer"
            :class="activeDropdown === 'trade' ? 'text-primary' : 'text-text-primary hover:text-primary'">
            Trade
            <svg class="ml-1 w-3 h-3 text-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </a>
          <div v-if="activeDropdown === 'trade'"
            class="absolute top-full left-0 mt-0 w-[600px] bg-[#181a20] border border-[#2b3139] rounded-lg shadow-2xl p-6">
            <div class="grid grid-cols-2 gap-8">
              <!-- Basic Section -->
              <div>
                <h3 class="text-[#848E9C] text-xs font-semibold mb-4 uppercase">Basic</h3>
                <div class="space-y-1">
                  <component :is="item.name === 'Spot' ? 'router-link' : 'a'" v-for="item in tradeDropdown.basic"
                    :key="item.name" :to="item.name === 'Spot' ? '/trade/BTC_USDT' : undefined"
                    :href="item.name !== 'Spot' ? '#' : undefined"
                    class="flex items-start gap-3 p-3 rounded hover:bg-[#2b3139] transition-colors group">
                    <span class="text-xl mt-0.5">{{ item.icon }}</span>
                    <div class="flex-1">
                      <div class="flex items-center gap-2">
                        <span class="text-white text-sm font-medium group-hover:text-primary">{{ item.name }}</span>
                        <span v-if="item.badge"
                          class="text-[10px] bg-primary text-black px-1.5 py-0.5 rounded font-bold">{{ item.badge
                          }}</span>
                      </div>
                      <p class="text-[#848E9C] text-xs mt-0.5">{{ item.desc }}</p>
                    </div>
                  </component>
                </div>
              </div>
              <!-- Advanced Section -->
              <div>
                <h3 class="text-[#848E9C] text-xs font-semibold mb-4 uppercase">Advanced</h3>
                <div class="space-y-1">
                  <component :is="item.path ? 'router-link' : 'a'" v-for="item in tradeDropdown.advanced"
                    :key="item.name" :to="item.path" :href="!item.path ? '#' : undefined"
                    class="flex items-start gap-3 p-3 rounded hover:bg-[#2b3139] transition-colors group">
                    <span class="text-xl mt-0.5">{{ item.icon }}</span>
                    <div class="flex-1">
                      <div class="flex items-center gap-2">
                        <span class="text-white text-sm font-medium group-hover:text-primary">{{ item.name }}</span>
                        <span v-if="item.badge"
                          class="text-[10px] bg-primary text-black px-1.5 py-0.5 rounded font-bold">{{ item.badge
                          }}</span>
                      </div>
                      <p class="text-[#848E9C] text-xs mt-0.5">{{ item.desc }}</p>
                    </div>
                  </component>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Futures Dropdown -->
        <div class="relative h-full" @mouseenter="activeDropdown = 'futures'" @mouseleave="activeDropdown = null">
          <a href="#" class="flex items-center h-full px-3 text-[14px] font-medium transition-colors cursor-pointer"
            :class="activeDropdown === 'futures' ? 'text-primary' : 'text-text-primary hover:text-primary'">
            Futures
            <svg class="ml-1 w-3 h-3 text-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </a>
          <div v-if="activeDropdown === 'futures'"
            class="absolute top-full left-0 mt-0 w-[400px] bg-[#181a20] border border-[#2b3139] rounded-lg shadow-2xl p-4">
            <div class="space-y-1">
              <component :is="item.path ? 'router-link' : 'a'" v-for="item in futuresDropdown" :key="item.name"
                :to="item.path" :href="!item.path ? '#' : undefined"
                class="flex items-start gap-3 p-3 rounded hover:bg-[#2b3139] transition-colors group">
                <span class="text-xl mt-0.5">{{ item.icon }}</span>
                <div class="flex-1">
                  <span class="text-white text-sm font-medium group-hover:text-primary">{{ item.name }}</span>
                  <p class="text-[#848E9C] text-xs mt-0.5">{{ item.desc }}</p>
                </div>
              </component>
            </div>
          </div>
        </div>

        <!-- Earn Dropdown -->
        <div class="relative h-full" @mouseenter="activeDropdown = 'earn'" @mouseleave="activeDropdown = null">
          <a href="#" class="flex items-center h-full px-3 text-[14px] font-medium transition-colors cursor-pointer"
            :class="activeDropdown === 'earn' ? 'text-primary' : 'text-text-primary hover:text-primary'">
            Earn
            <svg class="ml-1 w-3 h-3 text-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </a>
          <div v-if="activeDropdown === 'earn'"
            class="absolute top-full left-0 mt-0 w-[360px] bg-[#181a20] border border-[#2b3139] rounded-lg shadow-2xl p-4">
            <div class="space-y-1">
              <component :is="item.path ? 'router-link' : 'a'" v-for="item in earnDropdown" :key="item.name"
                :to="item.path" :href="!item.path ? '#' : undefined"
                class="flex items-start gap-3 p-3 rounded hover:bg-[#2b3139] transition-colors group">
                <span class="text-xl mt-0.5">{{ item.icon }}</span>
                <div class="flex-1">
                  <span class="text-white text-sm font-medium group-hover:text-primary block">{{ item.name }}</span>
                  <p class="text-[#848E9C] text-xs mt-0.5">{{ item.desc }}</p>
                </div>
              </component>
            </div>
          </div>
        </div>

        <!-- Square Dropdown -->
        <div class="relative h-full" @mouseenter="activeDropdown = 'square'" @mouseleave="activeDropdown = null">
          <a href="#" class="flex items-center h-full px-3 text-[14px] font-medium transition-colors cursor-pointer"
            :class="activeDropdown === 'square' ? 'text-primary' : 'text-text-primary hover:text-primary'">
            Square
            <svg class="ml-1 w-3 h-3 text-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </a>
          <div v-if="activeDropdown === 'square'"
            class="absolute top-full left-0 mt-0 w-[320px] bg-[#181a20] border border-[#2b3139] rounded-lg shadow-2xl p-4">
            <div class="space-y-1">
              <component :is="item.path ? 'router-link' : 'a'" v-for="item in squareDropdown" :key="item.name"
                :to="item.path" :href="!item.path ? '#' : undefined"
                class="flex items-start gap-3 p-3 rounded hover:bg-[#2b3139] transition-colors group">
                <span class="text-xl mt-0.5">{{ item.icon }}</span>
                <div class="flex-1">
                  <span class="text-white text-sm font-medium group-hover:text-primary block">{{ item.name }}</span>
                  <p class="text-[#848E9C] text-xs mt-0.5">{{ item.desc }}</p>
                </div>
              </component>
            </div>
          </div>
        </div>

        <!-- More Dropdown -->
        <div class="relative h-full" @mouseenter="activeDropdown = 'more'" @mouseleave="activeDropdown = null">
          <a href="#" class="flex items-center h-full px-3 text-[14px] font-medium transition-colors cursor-pointer"
            :class="activeDropdown === 'more' ? 'text-primary' : 'text-text-primary hover:text-primary'">
            More
            <svg class="ml-1 w-3 h-3 text-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </a>
          <div v-if="activeDropdown === 'more'"
            class="absolute top-full left-0 mt-0 w-[600px] bg-[#181a20] border border-[#2b3139] rounded-lg shadow-2xl p-6">
            <div class="grid grid-cols-2 gap-x-8 gap-y-1">
              <component :is="item.path ? 'router-link' : 'a'" v-for="item in moreDropdown" :key="item.name"
                :to="item.path" :href="!item.path ? '#' : undefined"
                class="flex items-start gap-3 p-3 rounded hover:bg-[#2b3139] transition-colors group">
                <span class="text-xl mt-0.5">{{ item.icon }}</span>
                <div class="flex-1">
                  <span class="text-white text-sm font-medium group-hover:text-primary block">{{ item.name }}</span>
                  <p class="text-[#848E9C] text-xs mt-0.5">{{ item.desc }}</p>
                </div>
              </component>
            </div>
          </div>
        </div>
      </nav>
    </div>

    <!-- Right Side: Utils & Auth -->
    <div class="flex items-center gap-4">
      <!-- Search -->
      <button class="p-1.5 text-text-primary hover:text-primary transition-colors">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      </button>

      <!-- Log In -->
      <a href="#"
        class="text-[14px] font-medium text-text-primary hover:text-primary transition-colors whitespace-nowrap">Log
        In</a>

      <!-- Sign Up Button -->
      <a href="#"
        class="bg-primary hover:bg-primary-hover text-black px-4 py-1.5 rounded-[4px] font-medium text-[14px] transition-colors whitespace-nowrap">
        Sign Up
      </a>

      <!-- Divider -->
      <div class="w-px h-5 bg-text-secondary/30 hidden sm:block"></div>

      <!-- App Download -->
      <button class="text-text-primary hover:text-primary hidden sm:block">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M12 18l0-12m-4 8l4 4 4-4m5 10H7" />
        </svg>
      </button>

      <!-- Globe / Language -->
      <button class="text-text-primary hover:text-primary hidden sm:block">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round"
            d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </button>

      <!-- Theme/More Toggle -->
      <button class="text-text-primary hover:text-primary hidden sm:block">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round"
            d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
        </svg>
      </button>

      <!-- Mobile Menu -->
      <button class="xl:hidden text-text-primary">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
    </div>
  </header>
  <!-- Spacer for fixed header -->
  <div v-if="isFixed" class="h-[64px]"></div>
</template>
