<script setup>
const headersLeft = ['Open', 'Delta', 'Bid Size', 'Bid/IV', 'Mark/IV', 'Ask/IV', 'Ask Size', 'Position']
const headersRight = ['Position', 'Bid Size', 'Bid/IV', 'Mark/IV', 'Ask/IV', 'Ask Size', 'Delta', 'Open']

const rows = [
    { strike: '84,000', call: { open: '0.00', delta: '0.99202', bidSize: '0.09', mark: '6,675.150', iv: '61.76%' }, put: { bidSize: '51.17', mark: '7.511', open: '8,378,665.06' } },
    { strike: '86,000', call: { open: '906.48', delta: '0.97573', bidSize: '0.12', mark: '4,640.312', iv: '52.22%' }, put: { bidSize: '0.00', mark: '10.000', open: '5,324,708.27' } },
    { strike: '88,000', call: { open: '824,903.73', delta: '0.96021', bidSize: '0.22', mark: '2,893.180', iv: '33.14%' }, put: { bidSize: '2.42', mark: '12.900', open: '3,850,719.40' } },
    { strike: '90,653.671', isATM: true, call: { open: '6,269,268.37', delta: '0.36394', bidSize: '3.00', mark: '231.815', iv: '20.00%' }, put: { bidSize: '6.00', mark: '563.231', open: '4,404,623.34' } },
    { strike: '91,000', call: { open: '7,350,916.41', delta: '0.07983', bidSize: '7.00', mark: '33.795', iv: '20.00%' }, put: { bidSize: '0.40', mark: '1,385.461', open: '1,786,687.09' } },
    { strike: '92,000', call: { open: '6,882,628.73', delta: '0.02472', bidSize: '14.20', mark: '10.841', iv: '24.92%' }, put: { bidSize: '0.23', mark: '2,356.594', open: '476,812.48' } },
    { strike: '94,000', call: { open: '6,941,882.19', delta: '0.01644', bidSize: '1.28', mark: '8.957', iv: '32.60%' }, put: { bidSize: '0.16', mark: '3,347.309', open: '323,616.08' } },
    { strike: '96,000', call: { open: '4,810,500.70', delta: '0.00919', bidSize: '13.04', mark: '6.875', iv: '46.81%' }, put: { bidSize: '0.12', mark: '5,339.456', open: '0.00' } },
]
</script>

<template>
    <div class="flex-1 overflow-hidden flex flex-col bg-[#0B0E11] select-none text-[12px]">
        <!-- Chain Header -->
        <div class="h-10 border-b border-[#2B3139] flex items-center bg-[#1A1D29]">
            <div class="flex-1 text-center font-bold text-[13px] text-white">Calls</div>
            <div
                class="flex-[0.6] flex flex-col items-center justify-center leading-tight py-1 bg-[#0B0E11]/50 h-full border-x border-[#2B3139]">
                <div class="text-[#848E9C] text-[10px]">BTCUSDT Price: <span class="text-[#0ECB81]">90,653.671</span>
                    ATM Vol: <span class="text-white">20.0%</span></div>
                <div class="flex items-center gap-2">
                    <span class="text-white font-bold text-[14px]">2026-01-11</span>
                    <span class="text-[#848E9C]">Time to Expiry: 23:23:14 (Daily)</span>
                </div>
            </div>
            <div class="flex-1 text-center font-bold text-[13px] text-white">Puts</div>
            <div class="flex-none px-4"><svg class="w-3.5 h-3.5 text-[#848E9C]" fill="none" stroke="currentColor"
                    viewBox="0 0 24 24">
                    <path d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" stroke-width="2" />
                </svg></div>
        </div>

        <!-- Table Columns -->
        <div class="flex items-center border-b border-[#2B3139] bg-[#1A1D29]/50 font-medium text-[#848E9C]">
            <div class="flex-1 grid grid-cols-8 px-2">
                <div v-for="h in headersLeft" :key="h" class="py-3 px-1">{{ h }}</div>
            </div>
            <div class="w-[100px] text-center py-2 px-1">Strike</div>
            <div class="flex-1 grid grid-cols-8 px-2">
                <div v-for="h in headersRight" :key="h" class="py-3 px-1 text-right">{{ h }}</div>
            </div>
        </div>

        <!-- Rows -->
        <div class="flex-1 overflow-y-auto no-scrollbar">
            <div v-for="row in rows" :key="row.strike" :class="row.isATM ? 'bg-[#2B3139]/30' : ''"
                class="flex items-center border-b border-[#2B3139]/30 hover:bg-[#2B3139]/10 transition-colors group">

                <!-- Calls Side -->
                <div class="flex-1 grid grid-cols-8 px-2 font-mono leading-tight py-3">
                    <div class="text-[#848E9C]">{{ row.call?.open || '--' }}</div>
                    <div class="text-[#0ECB81]">{{ row.call?.delta || '--' }}</div>
                    <div class="text-white">{{ row.call?.bidSize || '--' }}</div>
                    <div class="flex flex-col">
                        <span class="text-[#0ECB81]">0.0 / 0.00%</span>
                    </div>
                    <div class="flex flex-col">
                        <span class="text-white leading-none">{{ row.call?.mark || '--' }}</span>
                        <span class="text-[#848E9C] text-[10px] leading-none">{{ row.call?.iv || '' }}</span>
                    </div>
                    <div class="text-[#F6465D]">0.0 / -100.00%</div>
                    <div class="text-white">--</div>
                    <div class="text-[#848E9C]">--</div>
                </div>

                <!-- Strike Column -->
                <div
                    class="w-[110px] text-center py-3 font-bold h-full flex items-center justify-center border-x border-[#2B3139]/50">
                    <div :class="row.isATM ? 'bg-[#F0B90B] text-black rounded px-2 w-full mx-1' : 'text-white'">{{
                        row.strike }}</div>
                </div>

                <!-- Puts Side -->
                <div class="flex-1 grid grid-cols-8 px-2 font-mono text-right leading-tight py-3">
                    <div class="text-[#848E9C]">--</div>
                    <div class="text-white">{{ row.put?.bidSize || '--' }}</div>
                    <div class="text-[#0ECB81]">5.0 / 0.00%</div>
                    <div class="flex flex-col items-end">
                        <span class="text-white leading-none">{{ row.put?.mark || '--' }}</span>
                        <span class="text-[#848E9C] text-[10px] leading-none">61.56%</span>
                    </div>
                    <div class="text-[#F6465D]">15.0 / 67.32%</div>
                    <div class="text-white">8.63</div>
                    <div class="text-[#F6465D]">-0.00781</div>
                    <div class="overflow-hidden text-ellipsis text-[#848E9C]">{{ row.put?.open || '--' }}</div>
                </div>
            </div>

            <!-- Second Expiry Preview -->
            <div
                class="h-10 bg-[#1A1D29] border-y border-[#2B3139] flex items-center text-[#848E9C] text-[11px] font-medium mt-4">
                <div class="flex-1 text-center">Calls</div>
                <div class="flex-[0.6] text-center leading-tight">
                    BTCUSDT Price: <span class="text-[#0ECB81]">90,653.671</span> ATM Vol: <span
                        class="text-white">20.7%</span>
                    <br>
                    <span class="text-white font-bold">2026-01-12</span> Time to Expiry: 1day 23hr (Daily)
                </div>
                <div class="flex-1 text-center">Puts</div>
            </div>
        </div>
    </div>
</template>

<style scoped>
.no-scrollbar::-webkit-scrollbar {
    display: none;
}
</style>
