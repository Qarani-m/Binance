import { createRouter, createWebHistory } from "vue-router";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "home",
      component: () => import("@/views/HomePage.vue"),
    },
    {
      path: "/trade/:pair",
      name: "spot-trading",
      component: () => import("@/views/SpotTradingPage.vue"),
    },
    {
      path: "/futures",
      name: "futures-trading",
      component: () => import("@/views/FuturesTradingPage.vue"),
    },
    {
      path: "/coin-m",
      name: "coin-m-trading",
      component: () => import("@/views/CoinMFuturesTradingPage.vue"),
    },
    {
      path: "/options",
      name: "options-trading",
      component: () => import("@/views/OptionsTradingPage.vue"),
    },
    {
      path: "/earn",
      name: "earn-overview",
      component: () => import("@/views/EarnOverviewPage.vue"),
    },
    {
      path: "/earn/simple",
      name: "simple-earn",
      component: () => import("@/views/SimpleEarnPage.vue"),
    },
    {
      path: "/earn/advanced",
      name: "advanced-earn",
      component: () => import("@/views/AdvancedEarnPage.vue"),
    },
    {
      path: "/earn/loan",
      name: "loan",
      component: () => import("@/views/LoanPage.vue"),
    },
    {
      path: "/square",
      name: "square",
      component: () => import("@/views/SquarePage.vue"),
    },
    {
      path: "/blog",
      name: "blog",
      component: () => import("@/views/BlogPage.vue"),
    },
    {
      path: "/research",
      name: "research",
      component: () => import("@/views/ResearchPage.vue"),
    },
    {
      path: "/vip",
      name: "vip",
      component: () => import("@/views/VIPInstitutionalPage.vue"),
    },
    {
      path: "/academy",
      name: "academy",
      component: () => import("@/views/AcademyPage.vue"),
    },
    {
      path: "/web3wallet",
      name: "wallet",
      component: () => import("@/views/WalletPage.vue"),
    },
    {
      path: "/launchpool",
      name: "launchpool",
      component: () => import("@/views/LaunchpoolPage.vue"),
    },
    {
      path: "/markets",
      name: "markets",
      component: () => import("@/views/MarketPage.vue"),
    },
    {
      path: "/buy-crypto",
      name: "buy-crypto",
      component: () => import("@/views/BuyCryptoPage.vue"),
    },
  ],
});

export default router;
