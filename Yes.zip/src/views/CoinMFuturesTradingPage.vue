<script setup>
import { ref } from 'vue'
import AppHeader from '@/components/AppHeader.vue'
import CoinMFuturesTickerBar from '@/components/trading/CoinMFuturesTickerBar.vue'
import CoinMFuturesHeader from '@/components/trading/CoinMFuturesHeader.vue'
import CoinMFuturesOrderBook from '@/components/trading/CoinMFuturesOrderBook.vue'
import CoinMFuturesTrades from '@/components/trading/CoinMFuturesTrades.vue'
import CoinMFuturesTradeForm from '@/components/trading/CoinMFuturesTradeForm.vue'
</script>

<template>
    <div class="h-screen flex flex-col bg-[#0B0E11] text-[#EAECEF] overflow-hidden select-none">
        <!-- Section 1: Top Navigation Bar -->
        <AppHeader :isFixed="false" mode="futures" />

        <!-- Section 2: Trading Pair Ticker Bar -->
        <CoinMFuturesTickerBar />

        <!-- Main Content Area -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Section 3: Contract Header & Stats -->
            <CoinMFuturesHeader />

            <!-- Trading Layout: Charts and Sidebars -->
            <div class="flex-1 flex overflow-hidden">
                <!-- Center-Left: Chart and Bottom Tabs -->
                <div class="flex-1 flex flex-col border-r border-[#2B3139] min-w-0">
                    <!-- Section 4: Main Chart Area -->
                    <div class="flex-1 min-h-0 bg-[#181A20] flex flex-col">
                        <!-- Chart Tabs -->
                        <div
                            class="h-[40px] border-b border-[#2B3139] flex items-center px-4 gap-6 text-[12px] flex-none">
                            <span
                                class="text-[#F0B90B] border-b-2 border-[#F0B90B] h-full flex items-center font-medium cursor-pointer">Chart</span>
                            <span
                                class="text-[#848E9C] hover:text-white h-full flex items-center font-medium cursor-pointer">Info</span>
                            <span
                                class="text-[#848E9C] hover:text-white h-full flex items-center font-medium cursor-pointer">Trading
                                Data</span>
                            <div class="ml-auto flex items-center gap-3">
                                <svg class="w-3.5 h-3.5 text-[#848E9C] cursor-pointer hover:text-white" fill="none"
                                    stroke="currentColor" viewBox="0 0 24 24">
                                    <path d="M4 19h16M4 5h16M4 12h16" stroke-width="2" />
                                </svg>
                                <svg class="w-3.5 h-3.5 text-[#848E9C] cursor-pointer hover:text-white" fill="none"
                                    stroke="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"
                                        stroke-width="2" />
                                </svg>
                            </div>
                        </div>

                        <!-- Chart Toolbar -->
                        <div
                            class="h-9 border-b border-[#2B3139] flex items-center px-4 gap-4 text-[11px] text-[#848E9C] flex-none overflow-x-auto no-scrollbar">
                            <div class="flex items-center gap-2">
                                <span class="hover:text-white cursor-pointer px-1">Time</span>
                                <span class="hover:text-white cursor-pointer px-1 font-bold">15m</span>
                                <span class="hover:text-white cursor-pointer px-1">1H</span>
                                <span class="hover:text-white cursor-pointer px-1">4H</span>
                                <span class="text-[#F0B90B] border-b border-[#F0B90B] px-1 font-bold">1D</span>
                                <span class="hover:text-white cursor-pointer px-1">1W</span>
                                <svg class="w-2.5 h-2.5 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path d="M19 9l-7 7-7-7" stroke-width="2" />
                                </svg>
                            </div>
                            <div class="w-[1px] h-3 bg-[#2B3139]"></div>
                            <div class="flex items-center gap-3">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"
                                        stroke-width="2" />
                                </svg>
                                <div class="h-3 w-[1px] bg-[#2B3139]"></div>
                                <span>Indicators</span>
                            </div>
                            <div class="ml-auto flex items-center gap-4">
                                <span class="text-[#F0B90B] border-b border-[#F0B90B]">Original</span>
                                <span>TradingView</span>
                                <span>Depth</span>
                            </div>
                        </div>

                        <!-- Chart Visualization -->
                        <div class="flex-1 bg-[#181A20] relative flex items-center justify-center">
                            <div
                                class="absolute inset-0 opacity-5 flex items-center justify-center p-20 select-none pointer-events-none">
                                <svg class="w-96 h-96 text-white" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z" />
                                </svg>
                            </div>
                            <div class="text-center z-10 space-y-4">
                                <div class="text-5xl font-bold font-mono text-white/20 select-none">BTCUSD COIN-M</div>
                                <div class="flex gap-4 justify-center">
                                    <div class="h-24 w-1 bg-[#0ECB81]/20"></div>
                                    <div class="h-32 w-1 bg-[#F6465D]/20"></div>
                                    <div class="h-20 w-1 bg-[#0ECB81]/20"></div>
                                    <div class="h-40 w-1 bg-[#F6465D]/20"></div>
                                </div>
                            </div>
                            <!-- Price label overlay -->
                            <div
                                class="absolute right-[100px] top-[40%] bg-[#0ECB81] text-black px-1 text-[11px] font-mono rounded">
                                91,538.8</div>
                        </div>
                    </div>

                    <!-- Section 4 (Bottom): Tabs (Positions, etc.) -->
                    <div class="h-[250px] bg-[#181A20] border-t border-[#2B3139] flex flex-col flex-none">
                        <div
                            class="flex items-center gap-6 px-4 border-b border-[#2B3139] h-[40px] text-[12px] text-[#848E9C] flex-none">
                            <span
                                class="text-[#F0B90B] border-b-2 border-[#F0B90B] h-full flex items-center font-medium">Positions(0)</span>
                            <span class="hover:text-white cursor-pointer h-full flex items-center font-medium">Open
                                Orders(0)</span>
                            <span class="hover:text-white cursor-pointer h-full flex items-center font-medium">Order
                                History</span>
                            <span class="hover:text-white cursor-pointer h-full flex items-center font-medium">Trade
                                History</span>
                            <span
                                class="hover:text-white cursor-pointer h-full flex items-center font-medium underline decoration-dotted decoration-[#848E9C]">Assets</span>
                        </div>
                        <div class="flex-1 flex flex-col items-center justify-center text-[#848E9C]">
                            <div class="w-12 h-12 opacity-15 mb-3">
                                <svg fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm4.59-12.42L10 14.17l-2.59-2.58L6 13l4 4 8-8z" />
                                </svg>
                            </div>
                            <p class="text-sm">No positions found</p>
                        </div>
                    </div>
                </div>

                <!-- Middle Sidebar: Order Book and Trades -->
                <aside class="w-[280px] flex flex-col border-l border-[#2B3139] flex-none">
                    <!-- Section 5: Order Book -->
                    <div class="h-[48%] bg-[#181A20] border-b border-[#2B3139] flex flex-col flex-none overflow-hidden">
                        <CoinMFuturesOrderBook />
                    </div>
                    <!-- Section 6: Trades -->
                    <div class="flex-1 bg-[#181A20] flex flex-col overflow-hidden">
                        <CoinMFuturesTrades />
                    </div>
                </aside>

                <!-- Right Sidebar: Order Entry and Account Panel -->
                <aside class="w-[280px] flex flex-col border-l border-[#2B3139] flex-none">
                    <CoinMFuturesTradeForm />
                </aside>
            </div>
        </main>

        <!-- Section 8: Bottom Status & Ticker Bar -->
        <footer
            class="h-[30px] bg-[#0B0E11] border-t border-[#2B3139] flex items-center justify-between px-4 text-[10px] text-[#848E9C] flex-none">
            <div class="flex items-center gap-2">
                <div class="w-1.5 h-1.5 rounded-full bg-[#0ECB81] animate-pulse"></div>
                <span>Stable connection</span>
            </div>

            <!-- CM Scrolling Ticker -->
            <div class="flex-1 px-8 overflow-hidden">
                <div class="flex items-center gap-8 whitespace-nowrap animate-ticker-slow font-mono">
                    <span class="text-[#F6465D]">BTCUSD CM -0.21% ↓ 90,527.4</span>
                    <span class="text-[#F6465D]">ETHUSD CM -0.84% ↓ 3,084.04</span>
                    <span class="text-[#F6465D]">SOLUSD CM -2.11% ↓ 135.89</span>
                    <span class="text-[#F6465D]">ADAUSD CM -2.37% ↓ 0.7871</span>
                    <span class="text-[#0ECB81]">BNBUSD CM +1.19% ↑ 702.87</span>
                    <span class="text-[#F6465D]">XRPUSD CM -1.09% ↓ 2.0961</span>
                    <span class="text-[#F6465D]">DOGEUSD CM -1.01% ↓ 0.3976</span>
                </div>
            </div>

            <div class="flex gap-4 items-center">
                <span>Campaign Center</span>
                <span>Announcements</span>
                <span class="text-white/40 cursor-pointer hover:text-white">Cookie Preferences</span>
            </div>
        </footer>
    </div>
</template>

<style scoped>
.no-scrollbar::-webkit-scrollbar {
    display: none;
}

.no-scrollbar {
    -ms-overflow-style: none;
    scrollbar-width: none;
}

@keyframes ticker-slow {
    0% {
        transform: translateX(100%);
    }

    100% {
        transform: translateX(-100%);
    }
}

.animate-ticker-slow {
    display: flex;
    animation: ticker-slow 40s linear infinite;
}
</style>
