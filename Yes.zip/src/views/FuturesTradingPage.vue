<script setup>
import { ref } from 'vue'
import AppHeader from '@/components/AppHeader.vue'
import FuturesTickerBar from '@/components/trading/FuturesTickerBar.vue'
import FuturesHeader from '@/components/trading/FuturesHeader.vue'
import FuturesOrderBook from '@/components/trading/FuturesOrderBook.vue'
import FuturesTrades from '@/components/trading/FuturesTrades.vue'
import FuturesTradeForm from '@/components/trading/FuturesTradeForm.vue'

const activeSideTab = ref('trades')
</script>

<template>
    <div class="h-screen flex flex-col bg-[#0B0E11] text-[#EAECEF] overflow-hidden select-none">
        <!-- Section 1: Top Navigation Bar -->
        <AppHeader :isFixed="false" mode="futures" />

        <!-- Section 2: Trading Pair Ticker Bar -->
        <FuturesTickerBar />

        <!-- Main Content Area -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Section 3: Trading Pair Header & Stats -->
            <FuturesHeader />

            <!-- Trading Layout: Charts and Sidebars -->
            <div class="flex-1 flex overflow-hidden">
                <!-- Center-Left: Chart and Bottom Tabs -->
                <div class="flex-1 flex flex-col border-r border-[#2B3139] min-w-0">
                    <!-- Section 4: Main Chart Area -->
                    <div class="flex-1 min-h-0 bg-[#181A20] flex flex-col">
                        <!-- Chart Tabs -->
                        <div
                            class="h-[40px] border-b border-[#2B3139] flex items-center px-4 gap-6 text-[12px] flex-none">
                            <span
                                class="text-[#F0B90B] border-b-2 border-[#F0B90B] h-full flex items-center font-medium cursor-pointer">Chart</span>
                            <span
                                class="text-[#848E9C] hover:text-white h-full flex items-center font-medium cursor-pointer">Info</span>
                            <span
                                class="text-[#848E9C] hover:text-white h-full flex items-center font-medium cursor-pointer">Trading
                                Data</span>
                        </div>

                        <!-- Chart Toolbar -->
                        <div
                            class="h-9 border-b border-[#2B3139] flex items-center px-4 gap-4 text-[11px] text-[#848E9C] flex-none overflow-x-auto no-scrollbar">
                            <div class="flex items-center gap-2">
                                <span class="hover:text-white cursor-pointer px-1">Time</span>
                                <span class="hover:text-white cursor-pointer px-1">1s</span>
                                <span class="hover:text-white cursor-pointer px-1">15m</span>
                                <span class="hover:text-white cursor-pointer px-1">1H</span>
                                <span class="hover:text-white cursor-pointer px-1">4H</span>
                                <span class="text-[#F0B90B] border-b border-[#F0B90B] px-1 font-bold">1D</span>
                                <span class="hover:text-white cursor-pointer px-1">1W</span>
                            </div>
                            <div class="w-[1px] h-3 bg-[#2B3139]"></div>
                            <div class="flex items-center gap-3">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"
                                        stroke-width="2" />
                                </svg>
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                                        stroke-width="2" />
                                </svg>
                                <span class="text-[#F0B90B]">Original</span>
                                <span>TradingView</span>
                                <span>Depth</span>
                            </div>
                        </div>

                        <!-- Chart Visualization Area -->
                        <div class="flex-1 bg-[#181A20] relative flex items-center justify-center overflow-hidden">
                            <div
                                class="absolute inset-0 opacity-10 flex items-center justify-center p-20 pointer-events-none">
                                <svg class="w-full h-full text-white" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z" />
                                </svg>
                            </div>
                            <div class="text-center z-10">
                                <h2 class="text-4xl font-bold font-mono opacity-30 select-none">BTCUSDT PERPETUAL</h2>
                                <p class="text-[#848E9C] mt-2 opacity-50">Binance Futures Chart Visualization</p>
                            </div>
                        </div>
                    </div>

                    <!-- Section 4 (Bottom): Tabs (Positions, etc.) -->
                    <div class="h-[280px] bg-[#181A20] border-t border-[#2B3139] flex flex-col flex-none">
                        <div
                            class="flex items-center gap-6 px-4 border-b border-[#2B3139] h-[40px] text-[12px] text-[#848E9C] flex-none">
                            <span
                                class="text-[#F0B90B] border-b-2 border-[#F0B90B] h-full flex items-center font-medium">Positions(0)</span>
                            <span class="hover:text-white cursor-pointer h-full flex items-center font-medium">Open
                                Orders(0)</span>
                            <span class="hover:text-white cursor-pointer h-full flex items-center font-medium">Order
                                History</span>
                            <span class="hover:text-white cursor-pointer h-full flex items-center font-medium">Trade
                                History</span>
                            <span
                                class="hover:text-white cursor-pointer h-full flex items-center font-medium underline decoration-dotted">Assets</span>
                        </div>
                        <div class="flex-1 flex flex-col items-center justify-center text-[#848E9C]">
                            <div class="w-16 h-16 opacity-20 mb-2">
                                <svg fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M13 13v8h8v-8h-8zM3 21h8v-8H3v8zM3 3v8h8V3H3zm13.66 6.34L19.34 6.66 16.66 4l-2.68 2.66 2.68 2.68z" />
                                </svg>
                            </div>
                            <p class="text-sm">No data to display</p>
                        </div>
                    </div>
                </div>

                <!-- Right Sidebar: Order Book, Trades, Order Entry -->
                <aside class="w-[280px] flex flex-col border-l border-[#2B3139] flex-none">
                    <!-- Section 5: Order Book -->
                    <div
                        class="h-[380px] bg-[#181A20] border-b border-[#2B3139] flex flex-col flex-none overflow-hidden">
                        <FuturesOrderBook />
                    </div>
                    <!-- Section 6: Trades -->
                    <div class="flex-1 min-h-0 bg-[#181A20] border-b border-[#2B3139] flex flex-col overflow-hidden">
                        <FuturesTrades />
                    </div>
                    <!-- Section 7: Order Entry -->
                    <div class="h-[420px] bg-[#181A20] flex flex-col flex-none overflow-hidden">
                        <FuturesTradeForm />
                    </div>
                </aside>
            </div>
        </main>

        <!-- Section 8: Bottom Status & Ticker Bar -->
        <footer
            class="h-[30px] bg-[#0B0E11] border-t border-[#2B3139] flex items-center justify-between px-4 text-[10px] text-[#848E9C] flex-none">
            <div class="flex items-center gap-2">
                <div class="w-1.5 h-1.5 rounded-full bg-[#0ECB81] animate-pulse"></div>
                <span>Stable connection</span>
            </div>

            <!-- Bottom Scrolling Ticker -->
            <div class="flex-1 px-8 overflow-hidden">
                <div class="flex items-center gap-6 whitespace-nowrap animate-ticker-slow">
                    <span class="text-[#F6465D]">TUSDТ -6.45% ⬇ 0.4639</span>
                    <span class="text-[#F6465D]">BTCUSDT -0.07% ⬇ 90,622.0</span>
                    <span class="text-[#F6465D]">RIVERUSDT -16.57% ⬇ 13.062</span>
                    <span class="text-[#0ECB81]">PIPIPNUSDT +1.66% ⬆ 0.41302</span>
                    <span class="text-[#F6465D]">RVNUSDT -3.44% ⬇ 0.03936</span>
                    <span class="text-[#F6465D]">SULUSDT -0.02% ⬇ 1.8066</span>
                    <span class="text-[#F6465D]">DEEPUSDT -7.50% ⬇ 0.05079</span>
                    <span class="text-[#F6465D]">OGUSDТ -1.36%</span>
                </div>
            </div>

            <div class="flex gap-4 items-center">
                <a href="#" class="hover:text-white">Campaign Center</a>
                <a href="#" class="hover:text-white">Announcements</a>
                <a href="#" class="hover:text-white">Preferences</a>
            </div>
        </footer>
    </div>
</template>

<style scoped>
.no-scrollbar::-webkit-scrollbar {
    display: none;
}

.no-scrollbar {
    -ms-overflow-style: none;
    scrollbar-width: none;
}

@keyframes ticker-slow {
    0% {
        transform: translateX(100%);
    }

    100% {
        transform: translateX(-100%);
    }
}

.animate-ticker-slow {
    display: flex;
    animation: ticker-slow 60s linear infinite;
}
</style>

<style scoped>
.no-scrollbar::-webkit-scrollbar {
    display: none;
}

.no-scrollbar {
    -ms-overflow-style: none;
    scrollbar-width: none;
}
</style>
